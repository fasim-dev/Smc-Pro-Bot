SMC Pro Scalper — build APK from Android phone

Important: this is a UI-only prototype. It is NOT connected to Exness/MT5, does not display live prices, and cannot send trades.

EASIEST METHOD (GitHub Actions)
1. Create a new empty repository on GitHub using your Android browser.
2. Upload the contents of this project to the repository. The .github/workflows/build-apk.yml file must end up at exactly that path in the repository. The Android project folder `smc_pro_scalper_android_project` must be at repository root.
3. Open the repository's Actions tab. If prompted, enable Actions.
4. Choose “Build SMC Pro Scalper APK” and tap “Run workflow”.
5. Wait for the run to finish. Only if it says Success, open the run and download artifact `SMC-Pro-Scalper-debug-APK`.
6. Extract the downloaded artifact ZIP. Install `app-debug.apk`. Android may ask you to allow installs from your browser or file manager.
7. If build fails, open the failed run and check the log. No APK exists until the build succeeds.

Build locally requires Android SDK Platform 36, JDK 17, and Gradle 8.9. Output is app/build/outputs/apk/debug/app-debug.apk.
