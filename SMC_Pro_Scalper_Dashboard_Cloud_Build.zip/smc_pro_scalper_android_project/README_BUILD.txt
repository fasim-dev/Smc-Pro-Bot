SMC Pro Scalper Android UI prototype — NOT a connected trading app.

Requirements:
- Android Studio with Android SDK Platform 36 installed
- JDK 17 (Android Studio bundled JDK is recommended)
- Internet access on first Gradle sync to download dependencies

Build:
1. Extract this ZIP.
2. Open the extracted folder (the folder containing settings.gradle.kts) in Android Studio.
3. Accept the Gradle sync / install missing SDK Platform 36 prompts.
4. Wait for Gradle Sync to finish successfully.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK output is normally app/build/outputs/apk/debug/app-debug.apk.

This is only a UI prototype. It has no EA connection, no bridge, and sends no trading orders. Use demo only; do not use for live trading.
