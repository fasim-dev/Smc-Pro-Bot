package com.fasim.smcpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** UI-only scaffold. No trading command is sent in this first Android milestone. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var status by remember { mutableStateOf("Belum terhubung") }
                var demoNotice by remember { mutableStateOf(true) }
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("SMC Pro Scalper", style = MaterialTheme.typography.headlineMedium)
                        Text("XAUUSD · MT5 · Demo first", style = MaterialTheme.typography.titleMedium)
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Status robot", style = MaterialTheme.typography.titleMedium)
                                Text(status)
                                Text("AUTO default: OFF")
                                Text("Mode: DEMO ONLY")
                            }
                        }
                        if (demoNotice) {
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("Fail-safe aktif", style = MaterialTheme.typography.titleSmall)
                                    Text("UI ini belum terhubung ke bridge. Tidak ada order yang dikirim.")
                                }
                            }
                        }
                        Button(onClick = { status = "Bridge belum dikonfigurasi" }, modifier = Modifier.fillMaxWidth()) {
                            Text("Periksa koneksi")
                        }
                        OutlinedButton(onClick = { status = "AUTO OFF (UI prototype)" }, modifier = Modifier.fillMaxWidth()) {
                            Text("AUTO OFF")
                        }
                        Text("Jangan gunakan akun live pada tahap prototipe.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
